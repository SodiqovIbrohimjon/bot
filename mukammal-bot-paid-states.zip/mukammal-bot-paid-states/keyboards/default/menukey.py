from aiogram.types import ReplyKeyboardMarkup, KeyboardButton
from aiogram.types.reply_keyboard import ReplyKeyboardRemove

menuStart = ReplyKeyboardMarkup(
    keyboard = [
        [
            KeyboardButton(text = 'Qo`shish')
        ],
    ],
    resize_keyboard=True
)

menuStart1 = ReplyKeyboardMarkup(
    keyboard = [
        [
            KeyboardButton(text = 'Keyingi malumotlar ▶️')
        ],
    ],
    resize_keyboard=True
)