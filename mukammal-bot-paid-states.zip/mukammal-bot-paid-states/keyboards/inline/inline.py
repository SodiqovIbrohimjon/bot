from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

inlinemenu = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="1", callback_data="spalni"),
            InlineKeyboardButton(text="2", callback_data="spalni"),
            InlineKeyboardButton(text="3", callback_data="spalni"),
        ],
        [
            InlineKeyboardButton(text="4", callback_data="spalni"),
            InlineKeyboardButton(text="5", callback_data="spalni"),
            InlineKeyboardButton(text="6", callback_data="spalni"),
        ],
        [
            InlineKeyboardButton(text="7", callback_data="spalni"),
            InlineKeyboardButton(text="8", callback_data="spalni"),
            InlineKeyboardButton(text="9", callback_data="spalni"),
        ],
    ],
)

inlinemenu2 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="basseyn"),
            InlineKeyboardButton(text="Yo`q", callback_data="basseyn"),
        ],
    ],
)

inlinemenu3 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="baseyn"),
            InlineKeyboardButton(text="Yo`q", callback_data="baseyn"),
        ],
    ],
)

inlinemenu4 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="sauna"),
            InlineKeyboardButton(text="Yo`q", callback_data="sauna"),
        ],
    ],
)

inlinemenu5 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="turk"),
            InlineKeyboardButton(text="Yo`q", callback_data="turk"),
        ],
    ],
)

inlinemenu6 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="vanna"),
            InlineKeyboardButton(text="Yo`q", callback_data="vanna"),
        ],
    ],
)

inlinemenu7 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="tennis"),
            InlineKeyboardButton(text="Yo`q", callback_data="tennis"),
        ],
    ],
)

inlinemenu8 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="fotbol"),
            InlineKeyboardButton(text="Yo`q", callback_data="fotbol"),
        ],
    ],
)

inlinemenu9 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Bor", callback_data="bilyard"),
            InlineKeyboardButton(text="Yo`q", callback_data="bilyard"),
        ],
    ],
)

inlinemenu10 = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="Oqtosh", callback_data="joy"),
            InlineKeyboardButton(text="Bo`chka", callback_data="joy"),
            InlineKeyboardButton(text="Boshqa", callback_data="joy"),
        ],
    ],
)