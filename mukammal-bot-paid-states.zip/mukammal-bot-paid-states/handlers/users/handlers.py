import logging

from keyboards.default.menukey import menuStart1
from aiogram.types import message
from aiogram import types
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Command
from aiogram.dispatcher import filters
from states.personalData import PersonalData

from typing import Text
from keyboards.inline.inline import inlinemenu, inlinemenu2, inlinemenu3, inlinemenu4, inlinemenu5, inlinemenu6, inlinemenu7, inlinemenu8, inlinemenu9, inlinemenu10 
from aiogram.types import Message, CallbackQuery

from loader import dp

#@dp.message_handler(text_contains="Qo`shish")
#async def select_category(message: Message):
#    await message.answer(f"spalni sonini kiriting", reply_markup=inlinemenu)

@dp.message_handler(text_contains="Qo`shish")
async def enter_test(message: types.Message):
    await message.answer("Dacha rasmini kiriting(1tadan ko'p emas) Misol: <a href='https://telegra.ph/Rasm-kiriting-08-16'>Mana bunday</a>", reply_markup=menuStart1)

@dp.message_handler(text = "Keyingi malumotlar ▶️")
async def next_window(message: types.Message):
    await message.answer("Spalni sonini kiriting",reply_markup=inlinemenu)

@dp.callback_query_handler(text="spalni")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Basseyn bormi?", reply_markup=inlinemenu2)
    await call.message.delete()
    await call.answer(cache_time=60)
    
@dp.callback_query_handler(text="basseyn")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Yopiq Basseyn bormi?", reply_markup=inlinemenu3)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="baseyn")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Sauna bormi?", reply_markup=inlinemenu4)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="sauna")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Turk hammom bormi?", reply_markup=inlinemenu5)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="turk")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Vanna bormi?", reply_markup=inlinemenu6)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="vanna")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Tennis stol bormi?", reply_markup=inlinemenu7)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="tennis")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Footbal maydoni bormi?", reply_markup=inlinemenu8)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="fotbol")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Bilyard bormi?", reply_markup=inlinemenu9)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="bilyard")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Joylashuvni belgilang", reply_markup=inlinemenu10)
    await call.message.delete()
    await call.answer(cache_time=60)

@dp.callback_query_handler(text="joy")
async def baseyn(call: CallbackQuery):
    await call.message.answer("Sizning malumotlaringiz:\n Spalnilar soni: \n Basseyn: \n Yopiq basseyn: \n Sauna: \n Turk hammom: \n vanna: \n Stol tennis: \n Football maydoni: \n Bilyard: \n Joylashuv:  ")
    await call.message.delete()
    await call.answer(cache_time=60)